import { useState, useCallback, useRef } from 'react';
import type { Screen, CardData } from './types';
import Landing from './screens/Landing';
import PhotoUpload from './screens/PhotoUpload';
import PhotoEdit from './screens/PhotoEdit';
import Generator from './screens/Generator';
import Result from './screens/Result';

function generateId(): string {
  return 'HHG26-' + String(Math.floor(Math.random() * 9000) + 1000);
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('landing');
  const [cardData, setCardData] = useState<CardData>({
    photo: null,
    photoTransform: { x: 0, y: 0, zoom: 1, rotation: 0 },
    name: '',
    role: '',
    builderTitle: '',
    team: '',
    participantId: generateId(),
  });
  const [showShareModal, setShowShareModal] = useState(false);
  const [showToast, setShowToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const updateCard = useCallback((updates: Partial<CardData>) => {
    setCardData(prev => ({ ...prev, ...updates }));
  }, []);

  const navigate = useCallback((to: Screen) => {
    setScreen(to);
    window.scrollTo(0, 0);
  }, []);

  const showMessage = useCallback((msg: string, type: 'success' | 'error' = 'success') => {
    setShowToast({ msg, type });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setShowToast(null), 3200);
  }, []);

  const regenerateId = useCallback(() => {
    updateCard({ participantId: generateId() });
  }, [updateCard]);

  const sharedProps = { cardData, updateCard, navigate };
  const shareProps = { showShareModal, setShowShareModal, showMessage };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#FAF3E3' }}>
      {/* Global header */}
      <header style={{
        height: 72,
        backgroundColor: '#FFFFFF',
        borderBottom: '1px solid #E4DCC8',
        display: 'flex', alignItems: 'center',
        padding: '0 24px',
        position: 'sticky', top: 0, zIndex: 200,
      }}>
        <button
          onClick={() => navigate('landing')}
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: 'none', border: 'none', cursor: 'pointer', padding: 0,
          }}
          aria-label="Go to home"
        >
          <span style={{
            fontFamily: 'Inter, sans-serif', fontWeight: 700, fontSize: 15,
            color: '#16241D', letterSpacing: '-0.01em',
          }}>
            HH GOA 2026
          </span>
          <span style={{
            width: 7, height: 7, borderRadius: '50%',
            backgroundColor: '#F4C542', display: 'inline-block',
          }} />
        </button>
      </header>

      {/* Screen renderer */}
      <div className="fade-in" key={screen}>
        {screen === 'landing' && <Landing {...sharedProps} />}
        {screen === 'upload' && <PhotoUpload {...sharedProps} />}
        {screen === 'edit' && <PhotoEdit {...sharedProps} />}
        {screen === 'generator' && (
          <Generator {...sharedProps} {...shareProps} regenerateId={regenerateId} />
        )}
        {screen === 'result' && (
          <Result {...sharedProps} {...shareProps} />
        )}
      </div>

      {/* Toast */}
      {showToast && (
        <div
          onClick={() => setShowToast(null)}
          style={{
            position: 'fixed', bottom: 28, left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 999,
            backgroundColor: showToast.type === 'error' ? '#D6483A' : '#16241D',
            color: 'white',
            borderRadius: 14,
            padding: '12px 20px',
            display: 'flex', alignItems: 'center', gap: 10,
            boxShadow: '0 8px 24px rgba(0,0,0,0.18)',
            cursor: 'pointer',
            animation: 'fadeIn 0.25s ease',
            whiteSpace: 'nowrap',
          }}
        >
          {showToast.type === 'success' ? (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              stroke="#2E9E5B" strokeWidth="2.5" strokeLinecap="round">
              <path d="M20 6L9 17l-5-5" />
            </svg>
          ) : (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              stroke="white" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <circle cx="12" cy="16" r="1" fill="white" />
            </svg>
          )}
          <span style={{ fontFamily: 'Inter', fontWeight: 500, fontSize: 14 }}>
            {showToast.msg}
          </span>
        </div>
      )}
    </div>
  );
}

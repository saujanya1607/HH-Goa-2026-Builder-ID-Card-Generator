import { useRef, useState } from 'react';
import { toPng } from 'html-to-image';
import type { ScreenProps, CardData } from '../types';
import IDCard from '../components/IDCard';
import ShareModal from '../components/ShareModal';

interface ResultProps extends ScreenProps {
  showShareModal: boolean;
  setShowShareModal: (v: boolean) => void;
  showMessage: (msg: string, type?: 'success' | 'error') => void;
}

export default function Result({
  cardData, navigate,
  showShareModal, setShowShareModal, showMessage,
}: ResultProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);
  const [showBack, setShowBack] = useState(false);

  const handleDownload = async () => {
    if (!cardRef.current) return;
    setDownloading(true);
    try {
      const dataUrl = await toPng(cardRef.current, { pixelRatio: 3, cacheBust: true });
      const link = document.createElement('a');
      const safeName = (cardData.name || 'builder').toLowerCase().replace(/[^a-z0-9]+/g, '-');
      link.download = `hh-goa-2026-${safeName}.png`;
      link.href = dataUrl;
      link.click();
      showMessage('Downloaded as PNG.');
    } catch {
      showMessage("Couldn't download. Try again.", 'error');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <>
      <div style={{
        minHeight: 'calc(100vh - 72px)',
        backgroundColor: '#FAF3E3',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        padding: '56px 24px 100px',
        gap: 40,
      }}>
        {/* Header text */}
        <div style={{ textAlign: 'center', maxWidth: 480 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            backgroundColor: '#F3E4C4', borderRadius: 999, padding: '6px 16px',
            marginBottom: 16,
          }}>
            <span style={{ fontSize: 18 }}>🌴</span>
            <span style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 13, color: '#1F4D3A' }}>
              Badge ready
            </span>
          </div>
          <h2 style={{
            fontFamily: 'Fraunces, serif', fontWeight: 700, fontSize: 28,
            color: '#16241D', margin: 0, lineHeight: 1.2,
          }}>
            Your Goa builder badge is ready.
          </h2>
          <p style={{ fontFamily: 'Inter', fontSize: 14, color: '#4B5A50', margin: '10px 0 0', lineHeight: 1.5 }}>
            Download the PNG or share it straight to X.
          </p>
        </div>

        {/* Card with flip toggle */}
        <div style={{ position: 'relative', display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
          {/* Glow */}
          <div style={{
            position: 'absolute', width: 340, height: 520,
            borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(42,99,73,0.2) 0%, transparent 70%)',
            pointerEvents: 'none',
          }} />

          {/* Flip button */}
          <div style={{ position: 'relative', perspective: 1000 }}>
            <div style={{
              transform: showBack ? 'rotateY(180deg)' : 'rotateY(0)',
              transition: 'transform 0.4s ease',
              transformStyle: 'preserve-3d',
              position: 'relative',
            }}>
              {/* Front */}
              <div style={{ backfaceVisibility: 'hidden' }}>
                <IDCard ref={cardRef} data={cardData} />
              </div>
              {/* Back */}
              <div style={{
                position: 'absolute', top: 0, left: 0,
                backfaceVisibility: 'hidden',
                transform: 'rotateY(180deg)',
              }}>
                <IDCardBack data={cardData} />
              </div>
            </div>
          </div>

          <button
            onClick={() => setShowBack(b => !b)}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              background: 'none', border: '1px solid #E4DCC8',
              borderRadius: 999, padding: '6px 16px', cursor: 'pointer',
              fontFamily: 'Inter', fontSize: 12, fontWeight: 500, color: '#4B5A50',
            }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <polyline points="23 4 23 10 17 10" />
              <polyline points="1 20 1 14 7 14" />
              <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
            </svg>
            Flip card
          </button>
        </div>

        {/* Action buttons */}
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'center' }}>
          <button
            className="btn-primary"
            onClick={handleDownload}
            disabled={downloading}
            style={{ height: 52, padding: '0 32px', fontSize: 15 }}
          >
            {downloading ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                style={{ animation: 'spin 1s linear infinite' }}>
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
              </svg>
            )}
            Download ID
          </button>
          <button
            className="btn-secondary"
            onClick={() => setShowShareModal(true)}
            style={{ height: 52, padding: '0 28px', fontSize: 15, borderRadius: 999 }}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.259 5.63zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
            </svg>
            Share to X
          </button>
        </div>

        {/* Nav links */}
        <div style={{ display: 'flex', gap: 28 }}>
          <button className="btn-ghost" onClick={() => navigate('generator')}
            style={{ fontSize: 13, color: '#4B5A50' }}>
            Edit details
          </button>
          <button className="btn-ghost" onClick={() => navigate('edit')}
            style={{ fontSize: 13, color: '#4B5A50' }}>
            Change photo
          </button>
          <button className="btn-ghost" onClick={() => navigate('landing')}
            style={{ fontSize: 13, color: '#4B5A50' }}>
            Start over
          </button>
        </div>
      </div>

      {showShareModal && (
        <ShareModal
          cardData={cardData}
          cardRef={cardRef}
          onClose={() => setShowShareModal(false)}
          showMessage={showMessage}
        />
      )}
    </>
  );
}

// Card back — matches reference: white wordmark, large gold palm, barcode + emergency panel
function IDCardBack({ data }: { data: CardData }) {
  return (
    <div style={{
      width: 360, height: 576,
      borderRadius: 28,
      backgroundColor: '#1F4D3A',
      boxShadow: '0 20px 40px rgba(20,53,42,0.22)',
      position: 'relative',
      overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center',
      padding: '28px 24px 20px',
      gap: 12,
    }}>
      {/* Background white palm linework (sides) */}
      <svg style={{ position: 'absolute', inset: 0, opacity: 0.18 }} width="360" height="576" viewBox="0 0 360 576">
        <g stroke="white" fill="none" strokeLinecap="round">
          <path d="M 20 420 Q 28 340 36 280 Q 40 240 42 205" strokeWidth="4" />
          <path d="M 42 205 Q 70 170 104 182" strokeWidth="2.5" />
          <path d="M 42 205 Q 16 168 -8 178" strokeWidth="2.5" />
          <path d="M 42 205 Q 62 158 74 140" strokeWidth="2" />
          <path d="M 340 420 Q 332 340 324 280 Q 320 240 318 205" strokeWidth="4" />
          <path d="M 318 205 Q 290 170 256 182" strokeWidth="2.5" />
          <path d="M 318 205 Q 344 168 368 178" strokeWidth="2.5" />
          <path d="M 318 205 Q 298 158 286 140" strokeWidth="2" />
        </g>
      </svg>

      {/* Wordmark */}
      <div style={{ textAlign: 'center', zIndex: 1 }}>
        <div style={{
          fontFamily: 'Fraunces, serif', fontWeight: 700, fontSize: 28,
          color: 'white', letterSpacing: '0.04em',
        }}>
          HACKER HOUSE
        </div>
        <div style={{
          fontFamily: 'Inter', fontWeight: 600, fontSize: 11,
          color: '#F4C542', letterSpacing: '2px', textTransform: 'uppercase',
          marginTop: 6,
        }}>
          GOA · OCT 2026
        </div>
      </div>

      {/* Large gold palm tree — matches reference */}
      <svg width="180" height="200" viewBox="0 0 180 200" fill="none" style={{ zIndex: 1, marginTop: 8 }}>
        {/* Trunk */}
        <path d="M 92 196 Q 94 164 96 134 Q 98 110 98 90"
          stroke="#F4C542" strokeWidth="10" strokeLinecap="round" fill="none" />
        {/* Main fronds */}
        <path d="M 98 90 Q 138 52 170 64" stroke="#F4C542" strokeWidth="7" strokeLinecap="round" fill="none" />
        <path d="M 98 90 Q 58 52 26 64" stroke="#F4C542" strokeWidth="7" strokeLinecap="round" fill="none" />
        <path d="M 98 90 Q 128 38 144 16" stroke="#F4C542" strokeWidth="6" strokeLinecap="round" fill="none" />
        <path d="M 98 90 Q 68 38 52 16" stroke="#F4C542" strokeWidth="6" strokeLinecap="round" fill="none" />
        <path d="M 98 90 Q 108 30 116 10" stroke="#F4C542" strokeWidth="5" strokeLinecap="round" fill="none" />
        <path d="M 98 90 Q 88 30 80 10" stroke="#F4C542" strokeWidth="5" strokeLinecap="round" fill="none" />
        {/* Frond tips */}
        <path d="M 148 50 Q 164 42 176 48" stroke="#F4C542" strokeWidth="3.5" strokeLinecap="round" fill="none" />
        <path d="M 48 50 Q 32 42 18 46" stroke="#F4C542" strokeWidth="3.5" strokeLinecap="round" fill="none" />
        {/* Coconuts */}
        <circle cx="96" cy="96" r="9" fill="#F4C542" />
        <circle cx="108" cy="104" r="8" fill="#D4A800" />
        <circle cx="86" cy="104" r="7.5" fill="#D4A800" />
        {/* White highlight on fronds */}
        <path d="M 98 90 Q 138 52 170 64" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.25" />
        <path d="M 98 90 Q 58 52 26 64" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.25" />
      </svg>

      {/* Barcode panel */}
      <div style={{
        backgroundColor: '#F3E4C4',
        borderRadius: 10, padding: '10px 16px',
        width: 'calc(100% - 48px)', zIndex: 1,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
      }}>
        <svg width="240" height="40" style={{ display: 'block' }}>
          {/* Simple representative barcode */}
          {Array.from({ length: 38 }, (_, i) => {
            const w = [1, 1, 2, 1, 3, 1, 1, 2, 1, 1, 3, 2, 1, 1, 1, 2, 3, 1, 1, 2, 1, 1, 1, 3, 1, 2, 1, 1, 2, 1, 3, 1, 1, 1, 2, 1, 1, 2][i] || 1;
            const x = i * 6.3;
            return i % 2 === 0 ? <rect key={i} x={x} y={0} width={w * 2} height={40} fill="#1F4D3A" opacity="0.85" /> : null;
          })}
        </svg>
        <span style={{ fontFamily: 'Inter', fontSize: 11, color: '#1F4D3A', letterSpacing: '1px' }}>
          {data.participantId}
        </span>
      </div>

      {/* Emergency + Medical panel — matches reference */}
      <div style={{
        backgroundColor: '#F3E4C4',
        borderRadius: 10, padding: '14px 16px',
        width: 'calc(100% - 48px)', zIndex: 1,
        display: 'flex', flexDirection: 'column', gap: 12,
      }}>
        <div>
          <div style={{
            fontFamily: 'Inter', fontWeight: 700, fontSize: 11,
            color: '#E8447A', letterSpacing: '1.2px', textTransform: 'uppercase', marginBottom: 3,
          }}>
            Emergency Contact
          </div>
          <div style={{ fontFamily: 'Inter', fontSize: 12, color: '#4B5A50', fontStyle: 'italic' }}>
            [Name / Number Placeholder]
          </div>
        </div>
        <div style={{ borderTop: '1px solid #E4DCC8', paddingTop: 10 }}>
          <div style={{
            fontFamily: 'Inter', fontWeight: 700, fontSize: 11,
            color: '#E8447A', letterSpacing: '1.2px', textTransform: 'uppercase', marginBottom: 3,
          }}>
            Medical / Allergy Info
          </div>
          <div style={{ fontFamily: 'Inter', fontSize: 12, color: '#4B5A50', fontStyle: 'italic' }}>
            [Specific Details Placeholder]
          </div>
        </div>
      </div>
    </div>
  );
}

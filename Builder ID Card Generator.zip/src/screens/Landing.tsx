import type { ScreenProps } from '../types';
import IDCard from '../components/IDCard';

const DEMO_CARD = {
  photo: null,
  photoTransform: { x: 0, y: 0, zoom: 1, rotation: 0 },
  name: 'Saujanya S A',
  role: 'Frontend Developer',
  builderTitle: 'The Pixel Pirate',
  team: 'HH Goa Builders',
  participantId: 'HHG26-0427',
};

export default function Landing({ navigate }: ScreenProps) {
  return (
    <div style={{ backgroundColor: '#FAF3E3', minHeight: 'calc(100vh - 72px)' }}>
      {/* Desktop two-column hero */}
      <div style={{
        maxWidth: 1280,
        margin: '0 auto',
        padding: '0 48px',
        minHeight: 'calc(100vh - 72px)',
        display: 'flex',
        alignItems: 'center',
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: 64,
          alignItems: 'center',
          width: '100%',
          padding: '56px 0',
        }}>
          {/* Left: copy */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24, maxWidth: 480 }}>
            {/* Eyebrow */}
            <div style={{
              display: 'inline-flex', alignSelf: 'flex-start',
              backgroundColor: '#F3E4C4',
              borderRadius: 999,
              padding: '6px 14px',
            }}>
              <span style={{
                fontFamily: 'Inter', fontWeight: 700, fontSize: 12,
                color: '#1F4D3A', letterSpacing: '0.03em',
              }}>
                HACKER HOUSE · GOA 2026
              </span>
            </div>

            {/* Headline */}
            <h1 style={{
              fontFamily: 'Fraunces, serif',
              fontWeight: 700,
              fontSize: 'clamp(32px, 4vw, 44px)',
              lineHeight: 1.1,
              color: '#16241D',
              margin: 0,
            }}>
              Create your HH Goa 2026 Builder ID
            </h1>

            {/* Body */}
            <p style={{
              fontFamily: 'Inter', fontWeight: 400, fontSize: 16,
              lineHeight: 1.65, color: '#4B5A50', margin: 0,
            }}>
              Upload your photo, add your details, and generate your personalized
              Hacker House Goa badge — ready to download and share in under a minute.
            </p>

            {/* CTA */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'flex-start' }}>
              <button
                className="btn-primary"
                onClick={() => navigate('upload')}
                style={{ height: 56, padding: '0 32px', fontSize: 16 }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
                Create my ID
              </button>
              <span style={{ fontFamily: 'Inter', fontSize: 12, color: '#4B5A50' }}>
                No login. No signup. Takes under a minute.
              </span>
            </div>

            {/* Event details strip */}
            <div style={{
              display: 'flex', gap: 20, flexWrap: 'wrap', marginTop: 8,
            }}>
              {[
                { icon: '📍', label: 'Goa, India' },
                { icon: '📅', label: '28–31 Oct 2026' },
                { icon: '🏗️', label: 'Builders only' },
              ].map(({ icon, label }) => (
                <div key={label} style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  <span style={{ fontSize: 16 }}>{icon}</span>
                  <span style={{ fontFamily: 'Inter', fontSize: 13, color: '#4B5A50', fontWeight: 500 }}>
                    {label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: card preview */}
          <div style={{
            display: 'flex', justifyContent: 'center', alignItems: 'center',
            position: 'relative', perspective: 1000,
          }}>
            {/* Soft glow behind the card */}
            <div style={{
              position: 'absolute',
              width: 340, height: 520,
              borderRadius: '50%',
              backgroundColor: '#2A6349',
              filter: 'blur(90px)',
              opacity: 0.24,
            }} />

            {/* 3D-tilted card */}
            <div style={{
              transform: 'rotate(4deg) rotateY(-8deg) rotateX(2deg)',
              position: 'relative',
              transition: 'transform 0.4s ease',
            }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.transform = 'rotate(2deg) rotateY(-4deg) rotateX(1deg)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.transform = 'rotate(4deg) rotateY(-8deg) rotateX(2deg)';
              }}
            >
              <IDCard data={DEMO_CARD} scale={1} />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar with social proof */}
      <div style={{
        borderTop: '1px solid #E4DCC8',
        padding: '20px 48px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 48,
        backgroundColor: 'white',
        flexWrap: 'wrap',
      }}>
        {[
          'Free to generate',
          'Instant download as PNG',
          'No account needed',
          'Share to X in one tap',
        ].map(f => (
          <div key={f} style={{
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
              stroke="#2E9E5B" strokeWidth="2.5" strokeLinecap="round">
              <path d="M20 6L9 17l-5-5" />
            </svg>
            <span style={{ fontFamily: 'Inter', fontSize: 13, color: '#4B5A50', fontWeight: 500 }}>
              {f}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

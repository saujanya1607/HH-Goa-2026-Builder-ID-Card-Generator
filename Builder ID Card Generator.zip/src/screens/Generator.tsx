import { useRef, useState, useEffect, useCallback } from 'react';
import { toPng } from 'html-to-image';
import type { ScreenProps } from '../types';
import IDCard, { BUILDER_TITLES } from '../components/IDCard';
import ShareModal from '../components/ShareModal';

interface GeneratorProps extends ScreenProps {
  showShareModal: boolean;
  setShowShareModal: (v: boolean) => void;
  showMessage: (msg: string, type?: 'success' | 'error') => void;
  regenerateId: () => void;
}

export default function Generator({
  cardData, updateCard, navigate,
  showShareModal, setShowShareModal, showMessage, regenerateId,
}: GeneratorProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [showTeam, setShowTeam] = useState(!!cardData.team);
  const [cardKey, setCardKey] = useState(0);
  const [downloading, setDownloading] = useState(false);

  // Pulse card on field change
  const pulseCard = useCallback(() => {
    setCardKey(k => k + 1);
  }, []);

  const handleDownload = async () => {
    if (!cardRef.current) return;
    setDownloading(true);
    try {
      const dataUrl = await toPng(cardRef.current, {
        pixelRatio: 3,
        cacheBust: true,
      });
      const link = document.createElement('a');
      const safeName = (cardData.name || 'builder').toLowerCase().replace(/[^a-z0-9]+/g, '-');
      link.download = `hh-goa-2026-${safeName}.png`;
      link.href = dataUrl;
      link.click();
      showMessage('Downloaded as PNG.');
      setTimeout(() => navigate('result'), 400);
    } catch {
      showMessage('Couldn\'t download. Try again.', 'error');
    } finally {
      setDownloading(false);
    }
  };

  // Pulse card when cardData changes
  useEffect(() => {
    pulseCard();
  }, [cardData.name, cardData.role, cardData.builderTitle, cardData.team, pulseCard]);

  const canProceed = cardData.name.trim().length > 0;

  return (
    <>
      <div style={{ minHeight: 'calc(100vh - 72px)', backgroundColor: '#FAF3E3' }}>
        {/* Desktop: two-column */}
        <div style={{
          maxWidth: 1200,
          margin: '0 auto',
          padding: '40px 32px 120px',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: 40,
          alignItems: 'start',
        }}>
          {/* LEFT: Form panel */}
          <div style={{
            backgroundColor: 'white',
            borderRadius: 20,
            padding: '32px 28px',
            boxShadow: '0 2px 6px rgba(20,53,42,0.08)',
            position: 'sticky',
            top: 88,
          }}>
            {/* Step nav */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 28 }}>
              <CompletedDot />
              <StepLine />
              <CompletedDot />
              <StepLine />
              <ActiveDot />
            </div>

            <h2 style={{
              fontFamily: 'Fraunces, serif', fontWeight: 700, fontSize: 22,
              color: '#16241D', margin: '0 0 24px',
            }}>
              Your details
            </h2>

            {/* Photo section */}
            <Section label="1. Photo">
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                {cardData.photo ? (
                  <div style={{
                    width: 52, height: 52, borderRadius: 10,
                    overflow: 'hidden', border: '2px solid #E4DCC8', flexShrink: 0,
                  }}>
                    <img src={cardData.photo} alt="Your photo"
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  </div>
                ) : (
                  <div style={{
                    width: 52, height: 52, borderRadius: 10,
                    backgroundColor: '#F3E4C4', border: '2px solid #E4DCC8',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none"
                      stroke="#4B5A50" strokeWidth="1.5" opacity="0.5">
                      <circle cx="12" cy="8" r="4" /><path d="M4 20q0-4 4-6 2-1 4-1t4 1q4 2 4 6" />
                    </svg>
                  </div>
                )}
                <button
                  className="btn-ghost"
                  onClick={() => navigate('edit')}
                  style={{ fontSize: 13, color: '#E8447A', textDecoration: 'underline' }}
                >
                  {cardData.photo ? 'Change photo' : 'Add photo'}
                </button>
              </div>
            </Section>

            {/* Name */}
            <Section label="2. Name *">
              <div style={{ position: 'relative' }}>
                <input
                  className="input-field"
                  type="text"
                  placeholder="Saujanya S A"
                  value={cardData.name}
                  maxLength={40}
                  onChange={e => updateCard({ name: e.target.value })}
                  aria-label="Your name"
                />
                {cardData.name.length > 30 && (
                  <span style={{
                    position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                    fontFamily: 'Inter', fontSize: 11, color: '#4B5A50',
                  }}>
                    {cardData.name.length}/40
                  </span>
                )}
              </div>
            </Section>

            {/* Role */}
            <Section label="3. Stack / Role">
              <input
                className="input-field"
                type="text"
                placeholder="Frontend Developer"
                value={cardData.role}
                maxLength={30}
                onChange={e => updateCard({ role: e.target.value })}
                aria-label="Your role"
              />
            </Section>

            {/* Builder title */}
            <Section label="4. Builder title">
              <input
                className="input-field"
                type="text"
                placeholder="The Pixel Pirate"
                value={cardData.builderTitle}
                maxLength={32}
                onChange={e => updateCard({ builderTitle: e.target.value })}
                aria-label="Builder title"
                style={{ marginBottom: 10 }}
              />
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {BUILDER_TITLES.map(t => (
                  <button
                    key={t}
                    className={`chip ${cardData.builderTitle === t ? 'selected' : ''}`}
                    onClick={() => updateCard({ builderTitle: cardData.builderTitle === t ? '' : t })}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </Section>

            {/* Team disclosure */}
            <div style={{ marginTop: 4 }}>
              <button
                onClick={() => setShowTeam(p => !p)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  background: 'none', border: 'none', cursor: 'pointer',
                  fontFamily: 'Inter', fontSize: 13, fontWeight: 500, color: '#4B5A50',
                  padding: '6px 0',
                }}
              >
                <svg
                  width="14" height="14" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                  style={{ transform: showTeam ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }}
                >
                  <polyline points="9 18 15 12 9 6" />
                </svg>
                {showTeam ? 'Hide' : 'Add'} team info
              </button>

              {showTeam && (
                <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <div>
                    <label style={{ fontFamily: 'Inter', fontWeight: 500, fontSize: 12, color: '#4B5A50', display: 'block', marginBottom: 6 }}>
                      Team (optional)
                    </label>
                    <input
                      className="input-field"
                      type="text"
                      placeholder="HH Goa Builders"
                      value={cardData.team}
                      maxLength={30}
                      onChange={e => updateCard({ team: e.target.value })}
                      aria-label="Team name"
                    />
                  </div>
                  <div>
                    <label style={{ fontFamily: 'Inter', fontWeight: 500, fontSize: 12, color: '#4B5A50', display: 'block', marginBottom: 6 }}>
                      Participant ID
                    </label>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <input
                        className="input-field"
                        type="text"
                        value={cardData.participantId}
                        readOnly
                        style={{ backgroundColor: '#FAF3E3', cursor: 'default', color: '#4B5A50' }}
                      />
                      <button
                        onClick={regenerateId}
                        title="Regenerate ID"
                        style={{
                          width: 44, height: 48, borderRadius: 12, flexShrink: 0,
                          border: '1px solid #E4DCC8', backgroundColor: 'white', cursor: 'pointer',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                        }}
                      >
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                          stroke="#4B5A50" strokeWidth="2" strokeLinecap="round">
                          <polyline points="23 4 23 10 17 10" />
                          <polyline points="1 20 1 14 7 14" />
                          <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Download / Share */}
            <div style={{ display: 'flex', gap: 10, marginTop: 28 }}>
              <button
                className="btn-primary"
                onClick={handleDownload}
                disabled={!canProceed || downloading}
                style={{ flex: 1, height: 52, fontSize: 14 }}
                title={!canProceed ? 'Enter your name first' : ''}
              >
                {downloading ? (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                    style={{ animation: 'spin 1s linear infinite' }}>
                    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                  </svg>
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
                  </svg>
                )}
                {downloading ? 'Preparing…' : 'Download ID'}
              </button>
              <button
                className="btn-secondary"
                onClick={() => setShowShareModal(true)}
                disabled={!canProceed}
                style={{ flex: 1, height: 52, fontSize: 14, borderRadius: 999 }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.259 5.63zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
                Share to X
              </button>
            </div>
          </div>

          {/* RIGHT: Live card */}
          <div style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20,
            paddingTop: 8,
          }}>
            <div style={{
              position: 'sticky', top: 88,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16,
            }}>
              {/* Glow */}
              <div style={{
                position: 'relative',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <div style={{
                  position: 'absolute', width: 300, height: 450,
                  borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(42,99,73,0.18) 0%, transparent 70%)',
                  pointerEvents: 'none',
                }} />
                <div key={cardKey} style={{ animation: 'cardPulse 0.12s ease forwards' }}>
                  <IDCard ref={cardRef} data={cardData} />
                </div>
              </div>
              <p style={{ fontFamily: 'Inter', fontSize: 12, color: '#4B5A50', textAlign: 'center' }}>
                Your card updates live as you type
              </p>
            </div>
          </div>
        </div>

        {/* Mobile sticky bottom bar */}
        <div style={{
          position: 'fixed', bottom: 0, left: 0, right: 0,
          backgroundColor: 'white',
          borderTop: '1px solid #E4DCC8',
          padding: '12px 20px',
          paddingBottom: 'max(12px, env(safe-area-inset-bottom))',
          display: 'flex', gap: 10, zIndex: 100,
        }}>
          <button
            className="btn-primary"
            onClick={handleDownload}
            disabled={!canProceed || downloading}
            style={{ flex: 1, height: 52, fontSize: 14 }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Download ID
          </button>
          <button
            className="btn-secondary"
            onClick={() => setShowShareModal(true)}
            disabled={!canProceed}
            style={{ flex: 1, height: 52, fontSize: 14, borderRadius: 999 }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.259 5.63zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
            </svg>
            Share to X
          </button>
        </div>
      </div>

      {showShareModal && (
        <ShareModal
          cardData={cardData}
          cardRef={cardRef}
          onClose={() => setShowShareModal(false)}
          showMessage={showMessage}
        />
      )}
    </>
  );
}

function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <label style={{
        fontFamily: 'Inter', fontWeight: 600, fontSize: 12,
        color: '#4B5A50', letterSpacing: '0.04em', textTransform: 'uppercase',
        display: 'block', marginBottom: 8,
      }}>
        {label}
      </label>
      {children}
    </div>
  );
}

function CompletedDot() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <div style={{
        width: 10, height: 10, borderRadius: '50%',
        backgroundColor: '#2A6349',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{ width: 4, height: 4, borderRadius: '50%', backgroundColor: 'white' }} />
      </div>
    </div>
  );
}

function ActiveDot() {
  return (
    <div style={{
      width: 10, height: 10, borderRadius: '50%',
      backgroundColor: '#E8447A',
    }} />
  );
}

function StepLine() {
  return <div style={{ flex: 1, height: 2, backgroundColor: '#2A6349', maxWidth: 48, borderRadius: 2 }} />;
}

import { useState, useRef, useCallback } from 'react';
import type { ScreenProps } from '../types';
import IDCard from '../components/IDCard';

export default function PhotoEdit({ cardData, updateCard, navigate }: ScreenProps) {
  const { photoTransform } = cardData;
  const [isDragging, setIsDragging] = useState(false);
  const dragOrigin = useRef({ px: 0, py: 0, ox: 0, oy: 0 });

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    setIsDragging(true);
    dragOrigin.current = {
      px: e.clientX,
      py: e.clientY,
      ox: photoTransform.x,
      oy: photoTransform.y,
    };
  }, [photoTransform]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = (e.clientX - dragOrigin.current.px) / photoTransform.zoom;
    const dy = (e.clientY - dragOrigin.current.py) / photoTransform.zoom;
    updateCard({
      photoTransform: {
        ...photoTransform,
        x: dragOrigin.current.ox + dx,
        y: dragOrigin.current.oy + dy,
      },
    });
  }, [isDragging, photoTransform, updateCard]);

  const handlePointerUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 0.1 : -0.1;
    updateCard({
      photoTransform: {
        ...photoTransform,
        zoom: Math.max(0.8, Math.min(3, photoTransform.zoom + delta)),
      },
    });
  }, [photoTransform, updateCard]);

  const rotate = (dir: 1 | -1) => {
    const r = ((photoTransform.rotation + dir * 90) + 360) % 360;
    updateCard({ photoTransform: { ...photoTransform, rotation: r } });
  };

  const reset = () => {
    updateCard({ photoTransform: { x: 0, y: 0, zoom: 1, rotation: 0 } });
  };

  return (
    <div style={{
      minHeight: 'calc(100vh - 72px)',
      backgroundColor: '#FAF3E3',
      padding: '40px 24px',
    }}>
      <div style={{
        maxWidth: 960,
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: 40,
        alignItems: 'start',
      }}>
        {/* Left: controls */}
        <div style={{
          backgroundColor: 'white',
          borderRadius: 20,
          padding: '32px 28px',
          boxShadow: '0 2px 6px rgba(20,53,42,0.08)',
        }}>
          <button className="btn-ghost" onClick={() => navigate('upload')}
            style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 24, fontSize: 13 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            Change photo
          </button>

          <h2 style={{
            fontFamily: 'Fraunces, serif', fontWeight: 700, fontSize: 22,
            color: '#16241D', margin: '0 0 6px',
          }}>
            Adjust your photo
          </h2>
          <p style={{
            fontFamily: 'Inter', fontSize: 13, color: '#4B5A50',
            margin: '0 0 32px', lineHeight: 1.5,
          }}>
            Drag the card photo to reposition. Scroll to zoom.
          </p>

          {/* Zoom slider */}
          <div style={{ marginBottom: 24 }}>
            <label style={{
              fontFamily: 'Inter', fontWeight: 600, fontSize: 12,
              color: '#4B5A50', letterSpacing: '0.05em', textTransform: 'uppercase',
              display: 'block', marginBottom: 10,
            }}>
              Zoom — {Math.round(photoTransform.zoom * 100)}%
            </label>
            <input
              type="range"
              min="80" max="300"
              value={Math.round(photoTransform.zoom * 100)}
              onChange={(e) => updateCard({
                photoTransform: { ...photoTransform, zoom: Number(e.target.value) / 100 },
              })}
              style={{
                width: '100%', height: 4, cursor: 'pointer',
                accentColor: '#2A6349',
              }}
            />
          </div>

          {/* Rotate + Reset */}
          <div style={{ marginBottom: 28 }}>
            <label style={{
              fontFamily: 'Inter', fontWeight: 600, fontSize: 12,
              color: '#4B5A50', letterSpacing: '0.05em', textTransform: 'uppercase',
              display: 'block', marginBottom: 10,
            }}>
              Rotate
            </label>
            <div style={{ display: 'flex', gap: 8 }}>
              {[
                { label: 'Rotate left', icon: 'rotate-ccw', action: () => rotate(-1) },
                { label: 'Rotate right', icon: 'rotate-cw', action: () => rotate(1) },
                { label: 'Reset', icon: 'refresh', action: reset },
              ].map(({ label, icon, action }) => (
                <button
                  key={label}
                  onClick={action}
                  title={label}
                  style={{
                    width: 44, height: 44, borderRadius: 12,
                    border: '1px solid #E4DCC8',
                    backgroundColor: 'white', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    transition: 'background-color 0.15s',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#FAF3E3')}
                  onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'white')}
                >
                  {icon === 'rotate-ccw' && (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2A6349" strokeWidth="2" strokeLinecap="round">
                      <polyline points="1 4 1 10 7 10" />
                      <path d="M3.51 15a9 9 0 1 0 .49-3.5" />
                    </svg>
                  )}
                  {icon === 'rotate-cw' && (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2A6349" strokeWidth="2" strokeLinecap="round">
                      <polyline points="23 4 23 10 17 10" />
                      <path d="M20.49 15a9 9 0 1 1-.49-3.5" />
                    </svg>
                  )}
                  {icon === 'refresh' && (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4B5A50" strokeWidth="2" strokeLinecap="round">
                      <polyline points="23 4 23 10 17 10" />
                      <polyline points="1 20 1 14 7 14" />
                      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                    </svg>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Next button */}
          <button
            className="btn-primary"
            onClick={() => navigate('generator')}
            style={{ width: '100%', height: 52, fontSize: 15 }}
          >
            Next — Add details
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        {/* Right: live card preview */}
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16,
        }}>
          <div style={{ position: 'relative' }}>
            {/* Glow */}
            <div style={{
              position: 'absolute', inset: -40,
              background: 'radial-gradient(ellipse, rgba(42,99,73,0.15) 0%, transparent 70%)',
              pointerEvents: 'none',
            }} />
            <IDCard
              data={cardData}
              interactive={!!cardData.photo}
              onPhotoDragStart={handlePointerDown}
              onPhotoDrag={handlePointerMove}
              onPhotoDragEnd={handlePointerUp}
              onPhotoWheel={handleWheel}
            />
          </div>
          {cardData.photo && (
            <p style={{
              fontFamily: 'Inter', fontSize: 12, color: '#4B5A50',
              textAlign: 'center',
            }}>
              Drag the photo well to reposition · Scroll to zoom
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

import { useState, useRef, useCallback, type DragEvent, type ChangeEvent } from 'react';
import type { ScreenProps } from '../types';

type UploadState = 'idle' | 'dragging' | 'uploading' | 'error-format' | 'error-size' | 'error-camera';

const ACCEPTED = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
const MAX_BYTES = 20 * 1024 * 1024;

export default function PhotoUpload({ navigate, updateCard }: ScreenProps) {
  const [state, setState] = useState<UploadState>('idle');
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const processFile = useCallback((file: File) => {
    if (!ACCEPTED.includes(file.type) && !file.name.toLowerCase().endsWith('.heic')) {
      setState('error-format');
      return;
    }
    if (file.size > MAX_BYTES) {
      setState('error-size');
      return;
    }

    setState('uploading');
    let p = 0;
    const tick = setInterval(() => {
      p += Math.random() * 30;
      if (p >= 100) { p = 100; clearInterval(tick); }
      setProgress(Math.min(p, 100));
    }, 80);

    const reader = new FileReader();
    reader.onload = (e) => {
      clearInterval(tick);
      setProgress(100);
      setTimeout(() => {
        updateCard({
          photo: e.target?.result as string,
          photoTransform: { x: 0, y: 0, zoom: 1, rotation: 0 },
        });
        navigate('edit');
      }, 200);
    };
    reader.readAsDataURL(file);
  }, [navigate, updateCard]);

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setState('idle');
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  };

  const onFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
    e.target.value = '';
  };

  const tryCamera = () => {
    if (!navigator.mediaDevices && !('capture' in HTMLInputElement.prototype)) {
      setState('error-camera');
      return;
    }
    cameraInputRef.current?.click();
  };

  return (
    <div style={{
      minHeight: 'calc(100vh - 72px)',
      backgroundColor: '#FAF3E3',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '40px 24px',
    }}>
      <div style={{
        width: '100%', maxWidth: 560,
        backgroundColor: 'white',
        borderRadius: 20,
        padding: '40px 40px 36px',
        boxShadow: '0 2px 6px rgba(20,53,42,0.08)',
      }}>
        {/* Back link */}
        <button
          className="btn-ghost"
          onClick={() => navigate('landing')}
          style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 24, fontSize: 13 }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          Back
        </button>

        {/* Step indicator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 28 }}>
          <StepDot active label="Photo" />
          <StepLine />
          <StepDot label="Details" />
          <StepLine />
          <StepDot label="Preview" />
        </div>

        <h2 style={{
          fontFamily: 'Fraunces, serif', fontWeight: 700, fontSize: 24,
          color: '#16241D', margin: '0 0 8px',
        }}>
          Add your photo
        </h2>
        <p style={{
          fontFamily: 'Inter', fontSize: 14, color: '#4B5A50',
          margin: '0 0 28px', lineHeight: 1.5,
        }}>
          Use a clear portrait for the best result. Your photo stays on your device.
        </p>

        {/* Dropzone */}
        {state === 'uploading' ? (
          <UploadingState progress={progress} />
        ) : state === 'error-format' ? (
          <ErrorState
            icon="alert"
            msg="That image format isn't supported. Try JPG, PNG, or WebP."
            onRetry={() => setState('idle')}
          />
        ) : state === 'error-size' ? (
          <ErrorState
            icon="alert"
            msg="That image is too large (max 20 MB). Try compressing it first."
            onRetry={() => setState('idle')}
          />
        ) : state === 'error-camera' ? (
          <ErrorState
            icon="camera-off"
            msg="Camera access isn't available in this browser."
            retryLabel="Upload from device instead"
            onRetry={() => { setState('idle'); fileInputRef.current?.click(); }}
          />
        ) : (
          <div
            onDragOver={(e) => { e.preventDefault(); setState('dragging'); }}
            onDragLeave={() => setState('idle')}
            onDrop={onDrop}
            onClick={() => fileInputRef.current?.click()}
            style={{
              border: `2px dashed ${state === 'dragging' ? '#E8447A' : '#E4DCC8'}`,
              borderRadius: 20,
              height: 280,
              backgroundColor: state === 'dragging' ? '#FAF3E3' : 'white',
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', gap: 10,
              cursor: 'pointer',
              transition: 'border-color 0.15s, background-color 0.15s',
            }}
          >
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none"
              stroke={state === 'dragging' ? '#E8447A' : '#4B5A50'}
              strokeWidth="1.5" strokeLinecap="round" style={{ transition: 'stroke 0.15s' }}>
              <polyline points="16 16 12 12 8 16" />
              <line x1="12" y1="12" x2="12" y2="21" />
              <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" />
            </svg>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'Inter', fontWeight: 500, fontSize: 14, color: '#16241D' }}>
                Drag & drop or tap to upload
              </div>
              <div style={{ fontFamily: 'Inter', fontSize: 12, color: '#4B5A50', marginTop: 4 }}>
                JPG, PNG, WebP — up to 20 MB
              </div>
            </div>
          </div>
        )}

        {/* Action buttons */}
        {state !== 'uploading' && (
          <div style={{ display: 'flex', gap: 12, marginTop: 16, flexWrap: 'wrap' }}>
            <button
              className="btn-secondary"
              onClick={() => fileInputRef.current?.click()}
              style={{ height: 44, padding: '0 20px', flex: 1, fontSize: 14, borderRadius: 12 }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <polyline points="16 16 12 12 8 16" />
                <line x1="12" y1="12" x2="12" y2="21" />
                <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" />
              </svg>
              Upload photo
            </button>
            <button
              className="btn-secondary"
              onClick={tryCamera}
              style={{ height: 44, padding: '0 20px', flex: 1, fontSize: 14, borderRadius: 12 }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
                <circle cx="12" cy="13" r="4" />
              </svg>
              Take a photo
            </button>
          </div>
        )}

        {/* Hidden inputs */}
        <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={onFileChange} />
        <input ref={cameraInputRef} type="file" accept="image/*" capture="user" style={{ display: 'none' }} onChange={onFileChange} />
      </div>
    </div>
  );
}

function StepDot({ active, label }: { active?: boolean; label: string }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <div style={{
        width: 10, height: 10, borderRadius: '50%',
        backgroundColor: active ? '#2A6349' : '#E4DCC8',
        transition: 'background-color 0.2s',
      }} />
      <span style={{ fontFamily: 'Inter', fontSize: 10, color: active ? '#2A6349' : '#4B5A50', fontWeight: active ? 600 : 400 }}>
        {label}
      </span>
    </div>
  );
}

function StepLine() {
  return <div style={{ flex: 1, height: 1, backgroundColor: '#E4DCC8', marginBottom: 18, maxWidth: 48 }} />;
}

function UploadingState({ progress }: { progress: number }) {
  const r = 38;
  const circ = 2 * Math.PI * r;
  return (
    <div style={{
      border: '2px dashed #E4DCC8', borderRadius: 20, height: 280,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16,
    }}>
      <svg width="88" height="88" viewBox="0 0 88 88">
        <circle cx="44" cy="44" r={r} fill="none" stroke="#E4DCC8" strokeWidth="4" />
        <circle
          cx="44" cy="44" r={r}
          fill="none" stroke="#2A6349" strokeWidth="4"
          strokeDasharray={circ}
          strokeDashoffset={circ * (1 - progress / 100)}
          strokeLinecap="round"
          transform="rotate(-90 44 44)"
          style={{ transition: 'stroke-dashoffset 0.1s' }}
        />
        <text x="44" y="49" textAnchor="middle"
          style={{ fontFamily: 'Inter', fontSize: 14, fontWeight: 600, fill: '#2A6349' }}>
          {Math.round(progress)}%
        </text>
      </svg>
      <span style={{ fontFamily: 'Inter', fontSize: 13, color: '#4B5A50' }}>Preparing your photo…</span>
    </div>
  );
}

function ErrorState({ icon, msg, retryLabel, onRetry }: {
  icon: 'alert' | 'camera-off';
  msg: string;
  retryLabel?: string;
  onRetry: () => void;
}) {
  return (
    <div style={{
      border: '2px dashed #D6483A', borderRadius: 20, height: 280,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16,
      padding: '0 32px',
    }}>
      {icon === 'camera-off' ? (
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none"
          stroke="#D6483A" strokeWidth="1.5" strokeLinecap="round">
          <line x1="1" y1="1" x2="23" y2="23" />
          <path d="M21 21H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3m3-3h6l2 3h4a2 2 0 0 1 2 2v9.34" />
          <circle cx="12" cy="13" r="4" />
        </svg>
      ) : (
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none"
          stroke="#D6483A" strokeWidth="1.5" strokeLinecap="round">
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="12" />
          <circle cx="12" cy="16" r="1" fill="#D6483A" />
        </svg>
      )}
      <p style={{
        fontFamily: 'Inter', fontSize: 13, color: '#D6483A',
        textAlign: 'center', margin: 0, lineHeight: 1.5,
      }}>
        {msg}
      </p>
      <button className="btn-secondary" onClick={onRetry}
        style={{ height: 36, padding: '0 20px', fontSize: 13, borderRadius: 999, borderColor: '#D6483A', color: '#D6483A' }}>
        {retryLabel || 'Try again'}
      </button>
    </div>
  );
}

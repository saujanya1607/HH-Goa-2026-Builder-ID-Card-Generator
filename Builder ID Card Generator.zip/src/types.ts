export type Screen = 'landing' | 'upload' | 'edit' | 'generator' | 'result';

export interface PhotoTransform {
  x: number;
  y: number;
  zoom: number;
  rotation: number;
}

export interface CardData {
  photo: string | null;
  photoTransform: PhotoTransform;
  name: string;
  role: string;
  builderTitle: string;
  team: string;
  participantId: string;
}

export interface ScreenProps {
  cardData: CardData;
  updateCard: (updates: Partial<CardData>) => void;
  navigate: (screen: Screen) => void;
}

import { forwardRef, useId } from 'react';
import type { CardData } from '../types';

interface IDCardProps {
  data: CardData;
  scale?: number;
  interactive?: boolean;
  onPhotoDragStart?: (e: React.PointerEvent) => void;
  onPhotoDrag?: (e: React.PointerEvent) => void;
  onPhotoDragEnd?: (e: React.PointerEvent) => void;
  onPhotoWheel?: (e: React.WheelEvent) => void;
}

// Deterministic barcode from participant ID
function hashStr(s: string): number {
  let h = 5381;
  for (let i = 0; i < s.length; i++) {
    h = (((h << 5) + h) ^ s.charCodeAt(i)) >>> 0;
  }
  return h;
}

function makeBars(id: string): Array<{ w: number; isBar: boolean }> {
  let seed = hashStr(id || 'HHG26-0000');
  const result: Array<{ w: number; isBar: boolean }> = [];
  let total = 0;
  while (total < 230) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    const w = (seed % 4) + 1;
    const isBar = (seed & 0x8) !== 0;
    result.push({ w, isBar });
    total += w;
  }
  return result;
}

// The full tropical illustration SVG
function TropicalIllustration({ uid }: { uid: string }) {
  // Clip path for beach umbrellas
  const leftUmbClip = `lc-${uid}`;
  const rightUmbClip = `rc-${uid}`;
  const sandClip = `sc-${uid}`;

  return (
    <svg
      width="360" height="576" viewBox="0 0 360 576"
      style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 2 }}
      aria-hidden="true"
    >
      <defs>
        {/* Sand area clip — keeps umbrella stripes within canopy */}
        <clipPath id={leftUmbClip}>
          <path d="M 24 308 Q 62 270 100 308 Z" />
        </clipPath>
        <clipPath id={rightUmbClip}>
          <path d="M 262 308 Q 300 270 338 308 Z" />
        </clipPath>
        {/* Sand area clip for bottom of card */}
        <clipPath id={sandClip}>
          <path d="M 0 318 Q 90 310 180 316 Q 270 322 360 314 L 360 576 L 0 576 Z" />
        </clipPath>
      </defs>

      {/* === PALM TREES — white linework, both sides === */}
      {/* Left palm tree — tall, leans right */}
      <g opacity="0.30" stroke="white" fill="none" strokeLinecap="round" strokeLinejoin="round">
        {/* Trunk */}
        <path d="M 24 380 Q 32 310 40 260 Q 44 220 46 180" strokeWidth="5" />
        {/* Fronds left */}
        <path d="M 46 180 Q 78 142 122 158" strokeWidth="3.5" />
        <path d="M 46 180 Q 18 138 -4 148" strokeWidth="3.5" />
        <path d="M 46 180 Q 70 132 84 110" strokeWidth="3" />
        <path d="M 46 180 Q 30 134 18 115" strokeWidth="3" />
        <path d="M 46 180 Q 52 125 58 108" strokeWidth="2.5" />
        {/* Sub-frond tips */}
        <path d="M 90 148 Q 118 138 138 148" strokeWidth="2" />
        <path d="M 20 140 Q 2 132 -8 140" strokeWidth="2" />
        {/* Coconuts */}
        <circle cx="50" cy="184" r="6" fill="white" stroke="none" opacity="0.9" />
        <circle cx="60" cy="190" r="5" fill="white" stroke="none" opacity="0.8" />
        <circle cx="44" cy="192" r="4.5" fill="white" stroke="none" opacity="0.7" />
      </g>

      {/* Far-left skinny palm (smaller) */}
      <g opacity="0.18" stroke="white" fill="none" strokeLinecap="round">
        <path d="M 4 420 Q 8 360 12 310 Q 14 275 14 248" strokeWidth="3" />
        <path d="M 14 248 Q 32 222 56 234" strokeWidth="2" />
        <path d="M 14 248 Q -4 222 -18 230" strokeWidth="2" />
        <path d="M 14 248 Q 24 214 30 200" strokeWidth="1.5" />
        <path d="M 14 248 Q 4 214 -4 202" strokeWidth="1.5" />
      </g>

      {/* Right palm tree */}
      <g opacity="0.30" stroke="white" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M 336 380 Q 328 310 320 260 Q 316 220 314 180" strokeWidth="5" />
        <path d="M 314 180 Q 282 142 238 158" strokeWidth="3.5" />
        <path d="M 314 180 Q 342 138 364 148" strokeWidth="3.5" />
        <path d="M 314 180 Q 290 132 276 110" strokeWidth="3" />
        <path d="M 314 180 Q 330 134 342 115" strokeWidth="3" />
        <path d="M 314 180 Q 308 125 302 108" strokeWidth="2.5" />
        <path d="M 270 148 Q 242 138 222 148" strokeWidth="2" />
        <circle cx="310" cy="184" r="6" fill="white" stroke="none" opacity="0.9" />
        <circle cx="300" cy="190" r="5" fill="white" stroke="none" opacity="0.8" />
        <circle cx="316" cy="192" r="4.5" fill="white" stroke="none" opacity="0.7" />
      </g>

      {/* Far-right skinny palm */}
      <g opacity="0.18" stroke="white" fill="none" strokeLinecap="round">
        <path d="M 356 420 Q 352 360 348 310 Q 346 275 346 248" strokeWidth="3" />
        <path d="M 346 248 Q 328 222 304 234" strokeWidth="2" />
        <path d="M 346 248 Q 364 222 378 230" strokeWidth="2" />
        <path d="M 346 248 Q 336 214 330 200" strokeWidth="1.5" />
      </g>

      {/* === SUN — solid gold, to the right of photo well === */}
      <g>
        <circle cx="278" cy="148" r="22" fill="#F4C542" opacity="0.95" />
        {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((a, i) => {
          const rad = (a * Math.PI) / 180;
          return (
            <line
              key={i}
              x1={278 + 28 * Math.cos(rad)} y1={148 + 28 * Math.sin(rad)}
              x2={278 + 36 * Math.cos(rad)} y2={148 + 36 * Math.sin(rad)}
              stroke="#F4C542" strokeWidth="2.5" strokeLinecap="round" opacity="0.9"
            />
          );
        })}
      </g>

      {/* === WAVES — white linework, behind photo, mid-card === */}
      <g opacity="0.22" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round">
        {/* Waves to the left of photo */}
        <path d="M 0 220 Q 16 214 32 220 Q 48 226 64 220 Q 72 218 76 220" />
        <path d="M 0 232 Q 18 226 36 232 Q 54 238 72 232 Q 74 231 76 232" />
        <path d="M 0 244 Q 20 238 40 244 Q 60 250 76 244" />
        {/* Waves to the right of photo */}
        <path d="M 246 220 Q 262 214 278 220 Q 294 226 310 220 Q 330 214 360 218" />
        <path d="M 246 232 Q 264 226 282 232 Q 300 238 320 232 Q 342 226 360 230" />
        <path d="M 246 244 Q 266 238 286 244 Q 306 250 326 244 Q 346 238 360 242" />
        {/* Full-width waves below photo */}
        <path d="M 0 288 Q 30 280 60 288 Q 90 296 120 288 Q 150 280 180 288 Q 210 296 240 288 Q 270 280 300 288 Q 330 296 360 288" />
        <path d="M 0 300 Q 36 292 72 300 Q 108 308 144 300 Q 180 292 216 300 Q 252 308 288 300 Q 324 292 360 298" />
      </g>

      {/* === BEACH UMBRELLAS at sand boundary === */}
      {/* LEFT umbrella — pink with yellow stripes */}
      <g>
        {/* Canopy */}
        <path d="M 24 308 Q 62 270 100 308" fill="#E8447A" />
        {/* Yellow stripes clipped to canopy */}
        <rect x="44" y="268" width="9" height="44" fill="#F4C542" clipPath={`url(#${leftUmbClip})`} />
        <rect x="66" y="268" width="9" height="44" fill="#F4C542" clipPath={`url(#${leftUmbClip})`} />
        {/* Pole */}
        <line x1="62" y1="308" x2="64" y2="356" stroke="#F4C542" strokeWidth="2.5" />
        {/* Fringe line */}
        <path d="M 24 308 Q 62 314 100 308" stroke="#C82E62" strokeWidth="1.5" fill="none" opacity="0.6" />
      </g>

      {/* LEFT beach chair */}
      <g transform="translate(16, 334)" opacity="0.9">
        {/* Chair back */}
        <rect x="8" y="0" width="26" height="18" rx="3" fill="#2A6349" opacity="0.7" />
        {/* Seat */}
        <rect x="4" y="16" width="32" height="12" rx="3" fill="#2A6349" opacity="0.7" />
        {/* Legs */}
        <line x1="6" y1="28" x2="2" y2="44" stroke="#1F4D3A" strokeWidth="2" strokeLinecap="round" />
        <line x1="34" y1="28" x2="38" y2="44" stroke="#1F4D3A" strokeWidth="2" strokeLinecap="round" />
      </g>

      {/* RIGHT umbrella — yellow with pink stripes */}
      <g>
        <path d="M 262 308 Q 300 270 338 308" fill="#F4C542" />
        <rect x="280" y="268" width="9" height="44" fill="#E8447A" clipPath={`url(#${rightUmbClip})`} />
        <rect x="302" y="268" width="9" height="44" fill="#E8447A" clipPath={`url(#${rightUmbClip})`} />
        <line x1="300" y1="308" x2="298" y2="356" stroke="#E8447A" strokeWidth="2.5" />
        <path d="M 262 308 Q 300 314 338 308" stroke="#D4A800" strokeWidth="1.5" fill="none" opacity="0.6" />
      </g>

      {/* RIGHT beach chair */}
      <g transform="translate(306, 334)" opacity="0.9">
        <rect x="0" y="0" width="26" height="18" rx="3" fill="#2A6349" opacity="0.7" />
        <rect x="-4" y="16" width="32" height="12" rx="3" fill="#2A6349" opacity="0.7" />
        <line x1="2" y1="28" x2="-2" y2="44" stroke="#1F4D3A" strokeWidth="2" strokeLinecap="round" />
        <line x1="28" y1="28" x2="32" y2="44" stroke="#1F4D3A" strokeWidth="2" strokeLinecap="round" />
      </g>

      {/* === PINK SCOOTER in sand area, bottom-left === */}
      <g transform="translate(14, 468)" opacity="0.92">
        {/* Main body */}
        <path d="M 8 22 Q 10 10 24 8 Q 38 6 48 12 L 64 12 Q 72 12 74 22 L 78 30 Q 72 38 62 38 L 18 38 Q 8 38 8 28 Z"
          fill="#E8447A" />
        {/* Windshield */}
        <path d="M 48 12 Q 52 4 62 4 Q 70 4 74 12" fill="none" stroke="#C82E62" strokeWidth="2" strokeLinecap="round" />
        {/* Front wheel */}
        <circle cx="64" cy="40" r="11" stroke="#C82E62" strokeWidth="2.5" fill="none" />
        <circle cx="64" cy="40" r="5" fill="#C82E62" />
        <circle cx="64" cy="40" r="2" fill="#E8447A" />
        {/* Rear wheel */}
        <circle cx="16" cy="40" r="11" stroke="#C82E62" strokeWidth="2.5" fill="none" />
        <circle cx="16" cy="40" r="5" fill="#C82E62" />
        <circle cx="16" cy="40" r="2" fill="#E8447A" />
        {/* Handlebar */}
        <line x1="70" y1="12" x2="80" y2="4" stroke="#F4C542" strokeWidth="2.5" strokeLinecap="round" />
        <line x1="76" y1="3" x2="88" y2="3" stroke="#F4C542" strokeWidth="3" strokeLinecap="round" />
        {/* Headlight */}
        <circle cx="78" cy="20" r="4" fill="#F7D36B" />
        {/* Seat */}
        <rect x="26" y="6" width="20" height="7" rx="3" fill="#C82E62" />
        {/* Kick stand */}
        <line x1="28" y1="38" x2="22" y2="52" stroke="#C82E62" strokeWidth="2" strokeLinecap="round" />
      </g>

      {/* Sparkles / stars scattered */}
      <g fill="#F4C542" opacity="0.5">
        <path d="M 228 166 L 230 161 L 232 166 L 237 168 L 232 170 L 230 175 L 228 170 L 223 168 Z" />
        <path d="M 250 200 L 252 196 L 254 200 L 258 202 L 254 204 L 252 208 L 250 204 L 246 202 Z" />
      </g>
      <g opacity="0.5">
        <circle cx="232" cy="128" r="3" fill="#F4C542" />
        <circle cx="240" cy="122" r="2" fill="#F4C542" />
        <circle cx="244" cy="134" r="1.5" fill="#F4C542" />
      </g>
    </svg>
  );
}

// Sand/beach area as SVG with slightly wavy horizon
function SandArea() {
  return (
    <svg
      width="360" height="576" viewBox="0 0 360 576"
      style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 3 }}
      aria-hidden="true"
    >
      {/* Sand fill — slightly wavy top edge to simulate beach horizon */}
      <path
        d="M 0 322 Q 45 312 90 318 Q 135 324 180 318 Q 225 312 270 318 Q 315 324 360 316 L 360 576 L 0 576 Z"
        fill="#F3E4C4"
      />
    </svg>
  );
}

const BUILDER_TITLES = [
  'THE PIXEL PIRATE',
  'THE AI ARCHITECT',
  'THE CODE VOYAGER',
  'THE PRODUCT HACKER',
  'THE DEBUGGING WIZARD',
  'THE DESIGN REBEL',
];

const IDCard = forwardRef<HTMLDivElement, IDCardProps>(
  ({
    data,
    scale = 1,
    interactive = false,
    onPhotoDragStart,
    onPhotoDrag,
    onPhotoDragEnd,
    onPhotoWheel,
  }, ref) => {
    const uid = useId().replace(/:/g, '');
    const { photo, photoTransform, name, role, builderTitle, team, participantId } = data;

    const bars = makeBars(participantId);
    const totalW = bars.reduce((s, b) => s + b.w, 0);
    const bScale = 240 / Math.max(totalW, 1);

    const displayTitle = builderTitle
      ? builderTitle.toUpperCase()
      : 'HACKATHON TEAM';

    const nameFontSize = name.length > 20 ? 16 : name.length > 14 ? 19 : 22;

    return (
      <div
        ref={ref}
        style={{
          width: 360,
          height: 576,
          borderRadius: 28,
          backgroundColor: '#1F4D3A',
          position: 'relative',
          overflow: 'hidden',
          boxShadow: '0 20px 40px rgba(20,53,42,0.22)',
          transform: `scale(${scale})`,
          transformOrigin: 'top center',
          flexShrink: 0,
          userSelect: 'none',
        }}
        role="img"
        aria-label={`HH Goa 2026 builder badge for ${name || 'participant'}`}
      >
        {/* Subtle radial vignette */}
        <div style={{
          position: 'absolute', inset: 0, borderRadius: 28, zIndex: 1, pointerEvents: 'none',
          background: 'radial-gradient(ellipse at 50% 40%, transparent 45%, rgba(20,53,42,0.22) 100%)',
        }} />

        {/* Lanyard punch hole */}
        <div style={{
          position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)',
          width: 18, height: 18, borderRadius: '50%',
          backgroundColor: '#16352B',
          zIndex: 10, border: '2px solid rgba(255,255,255,0.15)',
        }} />

        {/* Tropical illustration layer */}
        <TropicalIllustration uid={uid} />

        {/* Sand / beach area — bottom of card */}
        <SandArea />

        {/* === HEADER AREA === */}

        {/* गोवा in large pink Devanagari above ribbon */}
        <div style={{
          position: 'absolute',
          top: 22, left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 8,
          textAlign: 'center',
        }}>
          <span style={{
            fontFamily: 'Inter, sans-serif',
            fontWeight: 900,
            fontSize: 26,
            color: '#E8447A',
            letterSpacing: '-0.02em',
            textShadow: '0 2px 8px rgba(20,53,42,0.3)',
            lineHeight: 1,
          }}>
            गोवा
          </span>
        </div>

        {/* Header ribbon — double-notch banner */}
        <div style={{
          position: 'absolute', top: 46, left: '50%',
          transform: 'translateX(-50%)',
          width: 322, height: 60,
          backgroundColor: '#F4C542',
          zIndex: 7,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          clipPath: 'polygon(16px 0%, calc(100% - 16px) 0%, 100% 50%, calc(100% - 16px) 100%, 16px 100%, 0% 50%)',
        }}>
          <span style={{
            fontFamily: 'Fraunces, serif',
            fontWeight: 700,
            fontSize: 30,
            color: '#1F4D3A',
            letterSpacing: '0.02em',
            lineHeight: 1,
          }}>
            HACKER HOUSE
          </span>
        </div>

        {/* Subheader: GOA, INDIA • 28–31 OCT 2026 */}
        <div style={{
          position: 'absolute', top: 114, left: 0, right: 0,
          textAlign: 'center', zIndex: 6,
        }}>
          <span style={{
            fontFamily: 'Inter, sans-serif',
            fontWeight: 600,
            fontSize: 11,
            letterSpacing: '1.8px',
            color: '#F4C542',
            textTransform: 'uppercase',
          }}>
            GOA, INDIA &nbsp;•&nbsp; 28 – 31 OCT 2026
          </span>
        </div>

        {/* === PHOTO WELL — portrait, yellow border, centered === */}
        <div
          style={{
            position: 'absolute',
            left: 76, top: 132,
            width: 156, height: 186,
            borderRadius: 14,
            border: '4px solid #F4C542',
            overflow: 'hidden',
            backgroundColor: '#F3E4C4',
            zIndex: 6,
            cursor: interactive && photo ? 'grab' : 'default',
          }}
          onPointerDown={interactive ? onPhotoDragStart : undefined}
          onPointerMove={interactive ? onPhotoDrag : undefined}
          onPointerUp={interactive ? onPhotoDragEnd : undefined}
          onPointerLeave={interactive ? onPhotoDragEnd : undefined}
          onWheel={interactive ? onPhotoWheel : undefined}
        >
          {photo ? (
            <img
              src={photo}
              alt="Profile photo"
              draggable={false}
              style={{
                position: 'absolute',
                left: '50%', top: '50%',
                minWidth: '100%', minHeight: '100%',
                width: 'auto', height: 'auto',
                transform: `translate(calc(-50% + ${photoTransform.x}px), calc(-50% + ${photoTransform.y}px)) scale(${photoTransform.zoom}) rotate(${photoTransform.rotation}deg)`,
                transformOrigin: 'center center',
                objectFit: 'cover',
                pointerEvents: 'none',
              }}
            />
          ) : (
            <div style={{
              width: '100%', height: '100%',
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', gap: 8,
              backgroundColor: '#F0DABC',
            }}>
              <svg width="44" height="44" viewBox="0 0 24 24" fill="none"
                stroke="#4B5A50" strokeWidth="1.25" strokeLinecap="round" opacity="0.45">
                <circle cx="12" cy="8" r="4" />
                <path d="M4 20c0-4 3.582-7 8-7s8 3 8 7" />
              </svg>
              <span style={{
                fontFamily: 'Inter', fontSize: 10, color: '#4B5A50',
                opacity: 0.6, fontWeight: 500,
              }}>
                Your photo
              </span>
            </div>
          )}
        </div>

        {/* === IDENTITY — sits on the cream sand area === */}
        {/* Name */}
        <div style={{
          position: 'absolute',
          top: 332, left: 16, right: 16,
          textAlign: 'center', zIndex: 6,
        }}>
          <div style={{
            fontFamily: 'Fraunces, serif',
            fontWeight: 700,
            fontSize: nameFontSize,
            color: '#1F4D3A',
            lineHeight: 1.15,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>
            {name || 'YOUR NAME'}
          </div>
        </div>

        {/* Role */}
        <div style={{
          position: 'absolute',
          top: 358, left: 16, right: 16,
          textAlign: 'center', zIndex: 6,
        }}>
          <div style={{
            fontFamily: 'Inter, sans-serif',
            fontWeight: 600,
            fontSize: 12,
            color: '#2A6349',
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>
            {role || 'Your Role'}
          </div>
        </div>

        {/* Builder title pill — pink banner */}
        <div style={{
          position: 'absolute',
          top: 378, left: 0, right: 0,
          display: 'flex', justifyContent: 'center', zIndex: 6,
        }}>
          <div style={{
            backgroundColor: '#E8447A',
            borderRadius: 5,
            padding: '5px 18px',
            clipPath: 'polygon(8px 0%, calc(100% - 8px) 0%, 100% 50%, calc(100% - 8px) 100%, 8px 100%, 0% 50%)',
            maxWidth: 280,
          }}>
            <span style={{
              fontFamily: 'Inter, sans-serif',
              fontWeight: 700,
              fontSize: 12,
              color: 'white',
              letterSpacing: '0.04em',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              display: 'block',
            }}>
              ✦ {displayTitle} ✦
            </span>
          </div>
        </div>

        {/* Team (conditional) */}
        {team && (
          <div style={{
            position: 'absolute',
            top: 406, left: 16, right: 16,
            textAlign: 'center', zIndex: 6,
          }}>
            <span style={{
              fontFamily: 'Inter', fontSize: 11, color: '#2A6349', fontWeight: 500,
            }}>
              {team}
            </span>
          </div>
        )}

        {/* Unique ID line */}
        <div style={{
          position: 'absolute',
          top: team ? 420 : 408, left: 16, right: 16,
          textAlign: 'center', zIndex: 6,
        }}>
          <span style={{
            fontFamily: 'Inter, sans-serif',
            fontWeight: 500,
            fontSize: 11,
            color: '#1F4D3A',
            letterSpacing: '0.04em',
          }}>
            UNIQUE ID: {participantId}
          </span>
        </div>

        {/* === BARCODE in sand area === */}
        <div style={{
          position: 'absolute',
          bottom: 22, left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 6,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
        }}>
          {/* Barcode bars — dark green on sand */}
          <svg width="240" height="42" style={{ display: 'block' }}>
            {(() => {
              let x = 0;
              return bars.map((bar, i) => {
                const bx = x * bScale;
                x += bar.w;
                if (!bar.isBar) return null;
                return (
                  <rect
                    key={i}
                    x={bx} y={2}
                    width={Math.max(bar.w * bScale - 0.6, 0.8)}
                    height={38}
                    fill="#1F4D3A"
                    opacity="0.85"
                  />
                );
              });
            })()}
          </svg>
          {/* Participant ID number */}
          <span style={{
            fontFamily: 'Inter, sans-serif',
            fontWeight: 500,
            fontSize: 10,
            color: '#1F4D3A',
            letterSpacing: '0.08em',
          }}>
            {participantId}
          </span>
          <span style={{
            fontFamily: 'Inter, sans-serif',
            fontWeight: 700,
            fontSize: 9,
            letterSpacing: '2px',
            color: '#1F4D3A',
            textTransform: 'uppercase',
            opacity: 0.65,
          }}>
            PARTICIPANT ID
          </span>
        </div>
      </div>
    );
  }
);

IDCard.displayName = 'IDCard';
export { BUILDER_TITLES };
export default IDCard;

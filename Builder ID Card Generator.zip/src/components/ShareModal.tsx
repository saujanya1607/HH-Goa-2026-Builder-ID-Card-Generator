import { useState, type RefObject } from 'react';
import { toPng } from 'html-to-image';
import type { CardData } from '../types';

interface ShareModalProps {
  cardData: CardData;
  cardRef: RefObject<HTMLDivElement | null>;
  onClose: () => void;
  showMessage: (msg: string, type?: 'success' | 'error') => void;
}

const DEFAULT_CAPTION = `Just made my Hacker House Goa 2026 builder badge 🌴⚡\nSee you in Goa.\n#HackerHouseGoa #BuildInGoa`;
const MAX_CHARS = 280;

export default function ShareModal({ cardData, cardRef, onClose, showMessage }: ShareModalProps) {
  const [caption, setCaption] = useState(DEFAULT_CAPTION);
  const [sharing, setSharing] = useState(false);

  const charsLeft = MAX_CHARS - caption.length;

  const handleShare = async () => {
    setSharing(true);
    try {
      // Try Web Share API first
      if (navigator.share && cardRef.current) {
        try {
          const dataUrl = await toPng(cardRef.current, { pixelRatio: 3, cacheBust: true });
          const blob = await (await fetch(dataUrl)).blob();
          const file = new File([blob], 'hh-goa-badge.png', { type: 'image/png' });
          if (navigator.canShare?.({ files: [file] })) {
            await navigator.share({ text: caption, files: [file] });
            onClose();
            return;
          }
        } catch {
          // Fall through to X direct link
        }
      }

      // Download image first, then open X with caption
      if (cardRef.current) {
        try {
          const dataUrl = await toPng(cardRef.current, { pixelRatio: 3, cacheBust: true });
          const link = document.createElement('a');
          link.download = `hh-goa-2026-${(cardData.name || 'badge').toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`;
          link.href = dataUrl;
          link.click();
        } catch {
          // Continue to X anyway
        }
      }

      const tweetUrl = `https://x.com/intent/tweet?text=${encodeURIComponent(caption)}`;
      window.open(tweetUrl, '_blank', 'noopener');
      onClose();
    } catch {
      showMessage("Couldn't share. Try downloading instead.", 'error');
    } finally {
      setSharing(false);
    }
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      style={{
        position: 'fixed', inset: 0, zIndex: 500,
        backgroundColor: 'rgba(20, 35, 29, 0.6)',
        display: 'flex', alignItems: 'flex-end',
        justifyContent: 'center',
        padding: '0 0 0 0',
        backdropFilter: 'blur(4px)',
      }}
    >
      {/* Sheet */}
      <div style={{
        backgroundColor: 'white',
        borderRadius: '24px 24px 0 0',
        width: '100%', maxWidth: 520,
        padding: '28px 28px 32px',
        boxShadow: '0 -8px 32px rgba(20,53,42,0.14)',
        animation: 'slideUp 0.28s ease',
      }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <h3 style={{
            fontFamily: 'Fraunces, serif', fontWeight: 700, fontSize: 20,
            color: '#16241D', margin: 0,
          }}>
            Share your badge
          </h3>
          <button
            onClick={onClose}
            style={{
              width: 36, height: 36, borderRadius: '50%',
              border: '1px solid #E4DCC8', backgroundColor: 'white',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
              stroke="#4B5A50" strokeWidth="2" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Preview + caption */}
        <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
          {/* Thumbnail */}
          <div style={{
            width: 80, height: 128, borderRadius: 12,
            overflow: 'hidden', flexShrink: 0,
            border: '1px solid #E4DCC8',
          }}>
            <div style={{
              width: 360, height: 576,
              backgroundColor: '#1F4D3A',
              transform: 'scale(0.222)',
              transformOrigin: 'top left',
              borderRadius: 28,
            }}>
              {/* Simplified card thumbnail */}
              <div style={{
                width: '100%', height: '100%',
                display: 'flex', flexDirection: 'column',
                alignItems: 'center', paddingTop: 40,
              }}>
                <div style={{
                  backgroundColor: '#F4C542', width: 280, height: 52, borderRadius: 4,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <span style={{ fontFamily: 'Fraunces, serif', fontWeight: 700, fontSize: 20, color: '#1F4D3A' }}>
                    HACKER HOUSE
                  </span>
                </div>
                <div style={{
                  marginTop: 16, width: 160, height: 160,
                  borderRadius: 14, border: '4px solid #F4C542',
                  backgroundColor: '#F3E4C4',
                  overflow: 'hidden',
                }}>
                  {cardData.photo && (
                    <img src={cardData.photo} alt=""
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Caption textarea */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
            <textarea
              value={caption}
              onChange={e => {
                if (e.target.value.length <= MAX_CHARS) setCaption(e.target.value);
              }}
              style={{
                flex: 1, minHeight: 120,
                border: '1px solid #E4DCC8', borderRadius: 12,
                padding: '12px 14px',
                fontFamily: 'Inter', fontSize: 13, lineHeight: 1.55, color: '#16241D',
                resize: 'none',
              }}
              placeholder="Write your caption…"
            />
            <div style={{
              textAlign: 'right', marginTop: 4,
              fontFamily: 'Inter', fontSize: 11,
              color: charsLeft < 20 ? '#D6483A' : '#4B5A50',
            }}>
              {charsLeft} remaining
            </div>
          </div>
        </div>

        {/* Browser compatibility note */}
        {!navigator.share && (
          <div style={{
            backgroundColor: '#FAF3E3',
            borderRadius: 10, padding: '10px 14px',
            marginBottom: 16,
            fontFamily: 'Inter', fontSize: 12, color: '#4B5A50', lineHeight: 1.5,
          }}>
            <strong>Note:</strong> Your badge will download automatically.
            Attach it when posting on X.
          </div>
        )}

        {/* Actions */}
        <div style={{ display: 'flex', gap: 10 }}>
          <button
            className="btn-primary"
            onClick={handleShare}
            disabled={sharing || charsLeft < 0}
            style={{ flex: 1, height: 52, fontSize: 14 }}
          >
            {sharing ? 'Sharing…' : (
              <>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.259 5.63zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
                Share to X
              </>
            )}
          </button>
          <button
            className="btn-secondary"
            onClick={onClose}
            style={{ height: 52, padding: '0 20px', fontSize: 14, borderRadius: 999 }}
          >
            Cancel
          </button>
        </div>
      </div>

    </div>
  );
}
